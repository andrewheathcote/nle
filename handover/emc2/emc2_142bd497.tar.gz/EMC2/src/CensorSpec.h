#ifndef CENSORSPEC_H
#define CENSORSPEC_H

#include <vector>
#include "RaceSetup.h"
#include "ParamTable.h"
#include "TruncSpec.h"


struct CensorSpec {
  std::vector<int>    idx_L;   // lower-censored rows, no response
  std::vector<int>    idx_U;   // upper-censored rows, no response
  std::vector<int>    idx_B;   // both-censored rows,  no response
  std::vector<double> LC;      // lower bounds (length n_trials, or empty)
  std::vector<double> UC;      // upper bounds (length n_trials, or empty)

  std::vector<int>    idx_L_tr;   // lower-censored trials
  std::vector<int>    idx_U_tr;   // upper-censored trials
  std::vector<int>    idx_B_tr;   // both-censored trials

  // Index lists — known-response cases, trial base rows (t * n_acc)
  // winner_*_known are parallel vectors holding the within-trial winner index [0, n_acc-1]
  std::vector<int> idx_L_known;      std::vector<int> winner_L_known;
  std::vector<int> idx_U_known;      std::vector<int> winner_U_known;
  std::vector<int> idx_B_known;      std::vector<int> winner_B_known;
  std::vector<bool> participating;

  std::vector<int>  idx_silent;       // base + k rows for silent accumulators
  std::vector<int>  winner_silent;    // parallel: accumulator index [0, n_acc-1]
  std::vector<bool> has_silent_trial; // length n_trials, for deferred log in fill_censored_rows
  std::vector<int>  idx_silent_trials;
  mutable std::vector<double> lo_silent, hi_silent, out_silent;

  // Integration buffers — sized to silent_acc.size()
  mutable std::vector<double> lo_mixed, hi_mixed, out_mixed;

  // Upper limit of integration for censoring
  double CENS_UPPER_CAP = 30.0;

  int n_rows    = 0;
  int n_trials  = 0;
  int n_acc     = 0;

  // Working buffers — length n_rows, filled by fill_truncate calls
  mutable std::vector<double> p_lower;   // S_k(LC - t0) per accumulator row
  mutable std::vector<double> p_upper;   // S_k(UC - t0) per accumulator row

  // Pre-allocated integration buffers — sized once in make_censor_spec,
  // reused every call to fill_censored_rows. Avoids heap allocation in the
  // particle loop. Sized to the largest known-response index list.
  mutable std::vector<double> lo_L,  hi_L,  out_L;   // lower-censored, known
  mutable std::vector<double> lo_U,  hi_U,  out_U;   // upper-censored, known
  mutable std::vector<double> lo1_B, hi1_B, out1_B;  // both-censored, known [LT, LC]
  mutable std::vector<double> lo2_B, hi2_B, out2_B;  // both-censored, known [UC, UT]

  // References to model objects — set at construction time, valid for
  // the lifetime of the particle loop (pt is mutated each iteration but
  // the pointer itself remains stable)
  const RaceModelSetup* setup   = nullptr;
  const ParamTable*     pt      = nullptr;
  RaceScratch*          scratch = nullptr;

  bool any() const {
    return !idx_L.empty() || !idx_U.empty() || !idx_B.empty() ||
      !idx_L_known.empty() || !idx_U_known.empty() || !idx_B_known.empty() ||
      !idx_silent.empty();
  }

  void fill_censored_rows(const TruncSpec& trunc,
                          std::vector<double>& ll_trial,
                          const bool return_log) const;

  // Update paramtable for multithreading
  void rebind(ParamTable& pt, RaceScratch& scratch) {
    this->pt      = &pt;
    this->scratch = &scratch;
  }
};


CensorSpec make_censor_spec(const Rcpp::DataFrame& data,
                            int n_trials,
                            int n_acc,
                            const std::vector<bool>& participating,
                            const RaceModelSetup* setup,
                            const ParamTable& pt,
                            RaceScratch& scratch);


#endif //CENSORSPEC_H
