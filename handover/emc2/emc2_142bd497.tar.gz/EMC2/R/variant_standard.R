sample_store_standard <- function(data, par_names, iters = 1, stage = "init", integrate = T, is_nuisance, ...) {
  subject_ids <- unique(data$subjects)
  n_subjects <- length(subject_ids)
  base_samples <- sample_store_base(data, par_names, iters, stage)
  par_names <- par_names[!is_nuisance]
  n_pars <- length(par_names)

  # Get total parameters including regressors
  group_designs <- list(...)$group_design
  total_par_names <- add_group_par_names(par_names, group_designs)

  # Check for random effects
  n_rand <- get_n_random(par_names, group_designs)
  n_s <- get_n_random_variance(par_names, group_designs) # Number of variance components

  # Create samples structure
  samples <- list(
    theta_mu = array(NA_real_,
      dim = c(length(total_par_names), iters),
      dimnames = list(total_par_names, NULL)
    ),
    theta_var = array(NA_real_,
      dim = c(n_pars, n_pars, iters),
      dimnames = list(par_names, par_names, NULL)
    ),
    a_half = array(NA_real_,
      dim = c(n_pars, iters),
      dimnames = list(par_names, NULL)
    )
  )
  if (n_rand > 0) {
    rand_names <- get_random_names(par_names, group_designs)
    samples$theta_u <- array(NA_real_, dim = c(n_rand, iters), dimnames = list(rand_names$u_names, NULL)) # Random effects
    samples$theta_s <- array(NA_real_, dim = c(n_s, iters), dimnames = list(rand_names$s_names, NULL)) # Variance components
    samples$a_half_s <- array(NA_real_, dim = c(n_s, iters), dimnames = list(rand_names$s_names, NULL)) # Auxiliary for s
  }

  if (integrate) samples <- c(samples, base_samples)
  return(samples)
}

add_info_standard <- function(sampler, prior = NULL, ...) {
  n_pars <- sum(!sampler$nuisance)
  group_design <- list(...)$group_design

  # Get all parameter names including regressors
  sampler$par_names_all <- add_group_par_names(sampler$par_names, group_design)

  sampler$par_group <- list(...)$par_groups
  if (is.null(sampler$par_group)) sampler$par_group <- rep(1, n_pars)
  sampler$is_blocked <- sampler$par_group %in% which(table(sampler$par_group) > 1)
  sampler$prior <- get_prior_standard(prior, n_pars,
    sample = F,
    group_design = group_design
  )
  sampler$group_designs <- group_design
  return(sampler)
}

calculate_mean_design <- function(group_designs, n_pars) {
  # Initialize the mean design matrix for each parameter
  mean_designs <- list()

  for (k in 1:n_pars) {
    if (is.null(group_designs) || is.null(group_designs[[k]])) {
      # If no design matrix, use a simple intercept
      mean_designs[[k]] <- matrix(1, nrow = 1, ncol = 1)
    } else {
      # Calculate the mean of the design matrix across subjects
      mean_designs[[k]] <- colMeans(group_designs[[k]], dims = 1)
    }
  }

  return(mean_designs)
}

calculate_implied_means <- function(mean_designs, beta_params, n_pars) {
  mu_implied <- numeric(n_pars)

  par_idx <- 0
  for (k in 1:n_pars) {
    x_k_mean <- mean_designs[[k]]
    mu_implied[k] <- x_k_mean %*% beta_params[par_idx + 1:length(x_k_mean)]
    par_idx <- par_idx + length(x_k_mean)
  }

  return(mu_implied)
}

.standard_diag_matrix <- function(x, n) {
  if (length(x) == 1L) return(diag(n) * x)
  diag(x)
}

.standard_square_matrix <- function(x, n, nm = NULL) {
  out <- matrix(x, nrow = n, ncol = n)
  if (!is.null(nm)) dimnames(out) <- list(nm, nm)
  out
}

.standard_theta_var_draws <- function(theta_var, idx) {
  if (is.logical(idx)) idx <- which(idx)
  theta_var <- theta_var[idx, idx, , drop = FALSE]
  n_pars <- length(idx)
  n_iter <- dim(theta_var)[3]
  out_len <- n_pars * (n_pars + 1) / 2
  out <- matrix(NA_real_, nrow = out_len, ncol = n_iter)
  nm <- dimnames(theta_var)[[1]]
  for (i in seq_len(n_iter)) {
    out[, i] <- unwind(.standard_square_matrix(theta_var[, , i], n_pars, nm))
  }
  out
}

.standard_prior_design_info <- function(design = NULL, group_design = NULL,
                                        nuisance = NULL, nuisance_non_hyper = NULL) {
  if (is.null(design)) {
    return(list(par_names = NULL, group_design = group_design))
  }

  par_names <- names(sampled_pars(design, doMap = FALSE))
  nuisance_idx <- unique(c(nuisance, nuisance_non_hyper))
  if (length(nuisance_idx) > 0L) {
    if (is.character(nuisance_idx)) {
      nuisance_idx <- match(nuisance_idx, par_names)
    }
    nuisance_idx <- nuisance_idx[!is.na(nuisance_idx)]
    if (length(nuisance_idx) > 0L) {
      par_names <- par_names[!seq_along(par_names) %in% nuisance_idx]
    }
  }

  if (!is.null(group_design)) {
    keep <- intersect(names(group_design), par_names)
    if (length(keep) == 0L) {
      group_design <- NULL
    } else {
      group_design <- group_design[keep]
      class(group_design) <- "emc.group_design"
    }
  }

  list(par_names = par_names, group_design = group_design)
}

get_prior_standard <- function(prior = NULL, n_pars = NULL, sample = TRUE, N = 1e5, selection = "mu", design = NULL, group_design = NULL,
                               par_groups = NULL, nuisance = NULL, nuisance_non_hyper = NULL){
  # Checking and default priors
  if (is.null(prior)) {
    prior <- list()
  }
  design_info <- .standard_prior_design_info(design, group_design, nuisance, nuisance_non_hyper)
  par_names <- design_info$par_names
  group_design <- design_info$group_design
  if(!is.null(design)){
    n_pars <- length(par_names)
  }
  if (!is.null(prior$A) & is.null(n_pars)) {
    n_pars <- length(prior$A)
  }

  # Number of additional parameters from design matrices
  if (!is.null(group_design)) {
    n_additional <- n_additional_group_pars(group_design)
  } else {
    n_additional <- 0
  }

  total_pars <- n_pars + n_additional
  # Set up combined theta_mu_mean to include both intercepts and slopes
  if(is.null(prior$theta_mu_mean) || length(prior$theta_mu_mean) == 0L) {
    prior$theta_mu_mean <- rep(0, total_pars)
  } else if (length(prior$theta_mu_mean) == 1L && total_pars > 1L) {
    prior$theta_mu_mean <- rep(prior$theta_mu_mean, total_pars)
  } else if (length(prior$theta_mu_mean) != total_pars) {
    stop("theta_mu_mean must be a scalar or match the number of group-level parameters")
  }
  theta_mu_names <- names(prior$theta_mu_mean)
  if (!is.null(design) && (is.null(theta_mu_names) || length(theta_mu_names) != length(prior$theta_mu_mean))) {
    theta_mu_names <- add_group_par_names(par_names, group_design)
    if (length(theta_mu_names) == length(prior$theta_mu_mean)) {
      names(prior$theta_mu_mean) <- theta_mu_names
    }
  }
  if(is.null(prior$theta_mu_var) || length(prior$theta_mu_var) == 0L){
    prior$theta_mu_var <- diag(total_pars)
  } else if (is.matrix(prior$theta_mu_var) &&
             (nrow(prior$theta_mu_var) != total_pars || ncol(prior$theta_mu_var) != total_pars)) {
    if (length(prior$theta_mu_var) == 1L) {
      prior$theta_mu_var <- diag(total_pars) * prior$theta_mu_var[1, 1]
    } else {
      stop("theta_mu_var matrix must match the number of group-level parameters")
    }
  } else if (!is.matrix(prior$theta_mu_var)) {
    if (length(prior$theta_mu_var) == 1L) {
      prior$theta_mu_var <- diag(total_pars) * prior$theta_mu_var
    } else if (length(prior$theta_mu_var) == total_pars) {
      prior$theta_mu_var <- .standard_diag_matrix(prior$theta_mu_var, total_pars)
    } else {
      stop("theta_mu_var must be a matrix, scalar, or vector matching the number of group-level parameters")
    }
  }
  if (!is.null(theta_mu_names) && length(theta_mu_names) == nrow(prior$theta_mu_var)) {
    dimnames(prior$theta_mu_var) <- list(theta_mu_names, theta_mu_names)
  }
  if (is.null(prior$v)) {
    prior$v <- 2
  }
  if (is.null(prior$A)) {
    prior$A <- rep(.3, n_pars)
  }
  n_s <- 0
  if (!is.null(group_design)) {
    # Use parameter names from design or group_design to count random effects
    pnames <- if (!is.null(design)) names(sampled_pars(design, doMap = FALSE)) else names(group_design)
    n_s <- get_n_random_variance(pnames, group_design)
    n_rand <- get_n_random(pnames, group_design)

    if (n_s > 0) {
      if (is.null(prior$v_Z)) {
        prior$v_Z <- 2
      }
      if (is.null(prior$A_z)) {
        prior$A_z <- rep(0.15, n_s)
      }
    }
  }
  # Things I save rather than re-compute inside the loops.
  prior$theta_mu_invar <- ginv(prior$theta_mu_var) # Inverse of the matrix
  attr(prior, "type") <- "standard"
  out <- prior
  if(sample){
    if (is.null(par_names) && !is.null(design)) {
      par_names <- names(sampled_pars(design, doMap = FALSE))
    }
    samples <- list()
    if (selection %in% c("mu", "beta", "alpha")) {
      # Sample beta (all parameters including regressors)
      beta <- t(mvtnorm::rmvnorm(N,
        mean = prior$theta_mu_mean,
        sigma = prior$theta_mu_var
      ))
      rownames(beta) <- add_group_par_names(par_names, group_design)
      if (selection %in% c("beta", "mu", "alpha")) {
        samples$theta_mu <- beta
        if (selection %in% c("mu", "alpha")) {
          samples$par_names <- par_names
          samples$group_designs <- group_design
        }
      }
    }
    if (selection %in% c("sigma2", "covariance", "correlation", "Sigma", "alpha")) {
      vars <- array(NA_real_, dim = c(n_pars, n_pars, N))
      colnames(vars) <- rownames(vars) <- par_names
      for (i in 1:N) {
        a_half <- 1 / rgamma(
          n = n_pars, shape = 1 / 2,
          rate = 1 / (prior$A^2)
        )
        attempt <- tryCatch(
          {
            vars[, , i] <- riwish(prior$v + n_pars - 1, 2 * prior$v * diag(1 / a_half))
          },
          error = function(e) e,
          warning = function(w) w
        )
        if (any(class(attempt) %in% c("warning", "error", "try-error"))) {
          sample_idx <- sample(1:(i - 1), 1)
          vars[, , i] <- vars[, , sample_idx]
        }
      }
      if (is.null(par_groups)) par_groups <- rep(1, n_pars)
      constraintMat <- matrix(0, n_pars, n_pars)
      for (i in 1:length(unique(par_groups))) {
        idx <- par_groups == i
        constraintMat[idx, idx] <- Inf
      }
      vars <- constrain_lambda(vars, constraintMat)
      if (selection != "alpha") samples$theta_var <- vars
    }

    # Sample random effects if present
    u <- NULL
    random_designs <- NULL
    random_maps <- NULL
    if (n_s > 0) {
      if (selection %in% c("s", "u", "alpha")) {
        # Sample s (variances)
        # s2 ~ IG(v_Z, A_z)
        # Actually s2_j ~ IG((v_Z+1)/2, A_z_j^2 * v_Z / 2)? No wait.
        # Gibbs step: s2 ~ IG((v+n)/2, (v*A^2 + sum(u^2))/2) ?
        # Prior for s2 implies:
        # We generally use similar to Sigma prior?
        # But here it's univariate variance per component.
        # Let's match the bridge sampler: prior_s <- dinvgamma(s2, shape = (v_Z + 1)/2, scale = (v_Z * A_z^2)/2)

        s2 <- matrix(NA, nrow = n_s, ncol = N)
        a_half_s <- matrix(NA, nrow = n_s, ncol = N)
        rand_names <- get_random_names(par_names, group_design)
        rownames(s2) <- rand_names$s_names
        rownames(a_half_s) <- rand_names$s_names

        for (j in 1:n_s) {
          # a_half_s ~ IG(1/2, 1/A_z^2)
          # shape = 1/2, rate = 1/(A_z^2)
          # R's rgamma uses rate, so IG sample is 1/rgamma(shape, rate)
          a_half_s[j, ] <- 1 / rgamma(N, shape = 1 / 2, rate = 1 / (prior$A_z[j]^2))

          # s2 | a_half_s ~ IG(v_Z/2, v_Z/a_half_s)
          # shape = v_Z/2, rate = v_Z/a_half_s
          # Note: rate for 1/rgamma is (v_Z / a_half_s)
          # s2 = 1 / rgamma(..., rate = v_Z / a_half_s)
          s2[j, ] <- 1 / rgamma(N, shape = prior$v_Z / 2, rate = prior$v_Z / a_half_s[j, ])
        }
        if (selection == "s") {
          samples$theta_s <- s2
          samples$a_half_s <- a_half_s
        }

        # Sample u
        # u ~ N(0, s2)
        if (selection %in% c("u", "alpha")) {
          # u is n_rand x N
          u <- matrix(NA, nrow = n_rand, ncol = N)
          rownames(u) <- rand_names$u_names

          # Map s2 to u components
          # Need to know which s corresponds to which u
          # get_random_names iterates same way
          idx_u <- 1
          idx_s <- 1

          # Re-iterate structure to check sizes
          for (p in par_names) {
            if (is.list(group_design[[p]]) && !is.null(group_design[[p]]$random)) {
              for (gname in names(group_design[[p]]$random)) {
                z <- group_design[[p]]$random[[gname]]
                k_z <- ncol(z)
                # s2[idx_s, ] is the variance for this block
                sd_vec <- sqrt(s2[idx_s, ])

                # For each of k_z levels, sample N times
                # u_block: k_z x N
                for (k in 1:k_z) {
                  u[idx_u + k - 1, ] <- rnorm(N, mean = 0, sd = sd_vec)
                }

                idx_u <- idx_u + k_z
                idx_s <- idx_s + 1
              }
            }
          }
          if (selection == "u") samples$theta_u <- u

          # Prepare for alpha
          if (selection == "alpha") {
            random_designs <- add_group_design_random(par_names, group_design)
            random_maps <- add_group_design_map(par_names, group_design)
          }
        }
      }
    }

    if (selection %in% "alpha") {
      samples <- list()
      samples$alpha <- get_alphas(beta, vars, design[[1]]$Ffactors$subjects,
        group_design = group_design, u = u, random_designs = random_designs, random_maps = random_maps
      )
    }
    out <- samples
  }
  return(out)
}

get_startpoints_standard <- function(pmwgs, start_mu, start_var) {
  n_pars <- sum(!pmwgs$nuisance)
  n_total_pars <- length(pmwgs$prior$theta_mu_mean) # Includes regressor parameters
  if (is.null(start_mu)) start_mu <- rmvnorm(1, mean = pmwgs$prior$theta_mu_mean, sigma = pmwgs$prior$theta_mu_var)[1, ]
  # If no starting point for group var just sample some
  if (is.null(start_var)) start_var <- riwish(n_pars * 3, diag(n_pars))
  start_a_half <- 1 / rgamma(n = n_pars, shape = 2, rate = 1)

  # Calculate subject-specific means using design matrices
  group_designs <- add_group_design(pmwgs$par_names[!pmwgs$nuisance], pmwgs$group_designs, pmwgs$n_subjects)
  # Needs to include random effects if present
  # For startpoints, if u is not provided, we can either sample it or set to 0.
  # Code below needs subj_mu to be computed including u.

  n_rand <- get_n_random(pmwgs$par_names, pmwgs$group_designs)
  u <- NULL
  s <- NULL
  a_half_s <- NULL
  if (n_rand > 0) {
    n_s <- get_n_random_variance(pmwgs$par_names, pmwgs$group_designs)

    # Initialize a_half_s from prior: IG(1/2, 1/A_z^2)
    # A_z might be scalar or vector in prior.
    A_z <- if (is.null(pmwgs$prior$A_z)) rep(0.3, n_s) else rep(pmwgs$prior$A_z, length.out = n_s)
    a_half_s <- 1 / rgamma(n_s, shape = 1 / 2, rate = 1 / (A_z^2))

    # Initialize s (variance) from prior: IG(v_Z/2, v_Z/a_half_s)
    v_Z <- if (is.null(pmwgs$prior$v_Z)) 2 else pmwgs$prior$v_Z
    s <- 1 / rgamma(n_s, shape = v_Z / 2, rate = v_Z / a_half_s)

    # Re-using logic from get_prior_standard for u generation
    u <- numeric(n_rand)
    idx_u <- 1
    idx_s <- 1
    # Iterate group designs to match s to u
    for (p in pmwgs$par_names[!pmwgs$nuisance]) {
      if (is.list(pmwgs$group_designs[[p]]) && !is.null(pmwgs$group_designs[[p]]$random)) {
        for (gname in names(pmwgs$group_designs[[p]]$random)) {
          z <- pmwgs$group_designs[[p]]$random[[gname]]
          k_z <- ncol(z)
          sd_val <- sqrt(s[idx_s])
          u[idx_u:(idx_u + k_z - 1)] <- rnorm(k_z, 0, sd_val)
          idx_u <- idx_u + k_z
          idx_s <- idx_s + 1
        }
      }
    }
  }

  random_designs <- add_group_design_random(pmwgs$par_names[!pmwgs$nuisance], pmwgs$group_designs)
  random_maps <- add_group_design_map(pmwgs$par_names[!pmwgs$nuisance], pmwgs$group_designs)
  subj_mu <- calculate_subject_means_RE(group_designs, start_mu, random_designs, u, random_maps)

  out <- list(
    tmu = start_mu, tvar = start_var, tvinv = ginv(start_var),
    a_half = start_a_half, subj_mu = subj_mu
  )

  if (!is.null(u)) {
    out$u <- u
    out$s <- s
    out$a_half_s <- a_half_s
  }
  return(out)
}

get_group_level_standard <- function(parameters, s) {
  # This function is modified for other versions
  mu <- parameters$subj_mu[, s]
  var <- parameters$tvar
  out <- list(mu = mu, var = var)
  if (!is.null(parameters$u)) out$u <- parameters$u
  if (!is.null(parameters$s)) {
    out$s <- parameters$s
    out$a_half_s <- parameters$a_half_s
  }
  return(out)
}

calculate_subject_means_RE <- function(group_designs, tmu, random_designs = NULL, u = NULL, random_maps = NULL) {
  # Calculate fixed effects
  mu <- calculate_subject_means(group_designs, tmu)

  # Add random effects if present
  if (!is.null(random_designs) && !is.null(u)) {
    # u is a concatenated vector. We need to split it based on random_maps.
    u_idx <- 1
    par_names <- names(group_designs)

    for (p in par_names) {
      if (!is.null(random_designs[[p]])) {
        # Loop over random components for this parameter
        z_list <- random_designs[[p]]
        maps <- random_maps[[p]]
        par_idx <- which(par_names == p) # Assuming row order matches list name order

        for (j in seq_along(z_list)) {
          z <- z_list[[j]]
          n_u <- ncol(z)
          u_curr <- u[u_idx:(u_idx + n_u - 1)]

          # Add to the appropriate row (parameter p)
          # mu is (n_pars x n_subjects)
          # z is (n_subjects x n_u)
          # u_curr is (n_u)
          # z %*% u_curr -> (n_subjects x 1)

          offset <- as.vector(z %*% u_curr)
          mu[par_idx, ] <- mu[par_idx, ] + offset

          u_idx <- u_idx + n_u
        }
      }
    }
  }
  return(mu)
}

fill_samples_standard <- function(samples, group_level, proposals, j = 1, n_pars) {
  samples$a_half[, j] <- group_level$a_half
  samples$last_theta_var_inv <- group_level$tvinv
  if (!is.null(group_level$u) && !is.null(samples$theta_u)) samples$theta_u[, j] <- group_level$u
  if (!is.null(group_level$s) && !is.null(samples$theta_s)) {
    samples$theta_s[, j] <- group_level$s
    samples$a_half_s[, j] <- group_level$a_half_s
  }
  samples <- fill_samples_base(samples, group_level, proposals, j = j, n_pars)
  return(samples)
}

gibbs_step_standard <- function(sampler, alpha) {
  #
  # alpha:  (p x n) subject-level parameter matrix
  #
  # sampler$group_designs:   list of length p, each (n x m_k)
  # sampler$is_blocked:    length p logical; is_blocked[k] = TRUE => param k is in some covariance block
  # sampler$par_group:     length p integer group labels (only used if is_blocked=TRUE)
  #
  # sampler$prior contains at least:
  #   - theta_mu_mean (length total_params) and theta_mu_invar (total_params x total_params)
  #   - v, A => hyperparams for the IW/Gamma updates
  #
  # last_sample_standard(...) must provide:
  #   - last$tmu (total_params-vector) of group means (includes both intercepts and slopes)
  #   - last$tvar, last$tvinv (p x p)
  #   - last$a_half (p)
  #
  # The function returns an updated (tmu, tvar, tvinv, a_half, alpha),
  # doing partial block updates for the covariance tvar, and a joint
  # update for all mu parameters (including former beta parameters)


  group_designs <- sampler$group_designs
  is_blocked <- sampler$is_blocked[!sampler$nuisance]
  par_group <- sampler$par_group[!sampler$nuisance]
  prior <- sampler$prior

  last <- last_sample_standard(sampler$samples)
  tmu <- last$tmu # group means, dimension total_params (includes former beta)
  tvar <- last$tvar # (p x p)
  tvinv <- last$tvinv
  a_half <- last$a_half # length p

  if (length(dim(alpha)) != 2L) {
    alpha <- matrix(alpha, nrow = sum(!sampler$nuisance), ncol = sampler$n_subjects)
    rownames(alpha) <- sampler$par_names[!sampler$nuisance]
  }

  p <- nrow(alpha)           # number of subject-level parameters
  n <- ncol(alpha)           # number of subjects

  # Extract Random Effects state
  u <- last$u
  s <- last$s
  a_half_s <- last$a_half_s

  if (is.null(p) || is.null(n)) {
    p <- sum(!sampler$nuisance)
    n <- sampler$n_subjects
    alpha <- matrix(alpha, nrow = p, ncol = n)
    rownames(alpha) <- sampler$par_names[!sampler$nuisance]
  }

  # Some backwards compatibility
  if (is.null(is_blocked) || length(is_blocked) == 0) {
    is_blocked <- rep(T, p)
  }
  if (is.null(par_group)) {
    par_group <- rep(1, p)
  }

  # Prepare designs
  fixed_designs <- add_group_design(sampler$par_names[!sampler$nuisance], group_designs, n)
  random_designs <- add_group_design_random(sampler$par_names[!sampler$nuisance], group_designs)
  random_maps <- add_group_design_map(sampler$par_names[!sampler$nuisance], group_designs)



  n_rand <- get_n_random(sampler$par_names[!sampler$nuisance], group_designs)
  has_random <- n_rand > 0

  M <- length(tmu) # Total parameters (former mu + beta)

  ## --------------------------------------------------
  ## 1) Update Beta (Fixed Effects)
  ## --------------------------------------------------
  # Target: alpha - Zu
  alpha_star <- alpha
  if (has_random && !is.null(u)) {
    # Compute Zu offset
    # Compute Zu offset manually relative to alpha to get residuals
    u_idx <- 1
    for (k in seq_len(p)) {
      pname <- names(fixed_designs)[k]
      if (!is.null(random_designs[[pname]])) {
        for (z in random_designs[[pname]]) {
          n_u <- ncol(z)
          offset <- as.vector(z %*% u[u_idx:(u_idx + n_u - 1)])
          alpha_star[k, ] <- alpha_star[k, ] - offset
          u_idx <- u_idx + n_u
        }
      }
    }
  }

  prec_data <- matrix(0, M, M)
  mean_data <- numeric(M)

  # For each subject i, we build an (p x M) matrix that maps tmu -> predicted alpha_i
  for (i in seq_len(n)) {
    par_idx <- 0
    M_i <- matrix(0, nrow = p, ncol = M)
    for (k in seq_len(p)) {
      x_ik <- fixed_designs[[k]][i, , drop = FALSE]
      # place them in row k:
      M_i[k, par_idx + 1:ncol(fixed_designs[[k]])] <- x_ik
      par_idx <- par_idx + ncol(fixed_designs[[k]])
    }
    # Accumulate
    prec_data <- prec_data + crossprod(M_i, tvinv %*% M_i)
    mean_data <- mean_data + crossprod(M_i, tvinv %*% alpha_star[, i, drop = FALSE])
  }

  prec_post <- prior$theta_mu_invar + prec_data
  cov_post <- solve(prec_post)
  mean_post <- cov_post %*% (prior$theta_mu_invar %*% prior$theta_mu_mean + mean_data)

  # Draw new parameter vector
  L <- t(chol(cov_post))
  z <- rnorm(M)
  tmu_new <- as.vector(mean_post + L %*% z)

  ## --------------------------------------------------
  ## 2) Update Random Effects u
  ## --------------------------------------------------
  u_new <- u
  s_new <- s
  a_half_s_new <- a_half_s

  if (has_random) {
    # Calculate mu_fixed = X * beta
    mu_fixed <- calculate_subject_means(fixed_designs, tmu_new)

    # We iterate over each random component
    u_ptr <- 1
    s_ptr <- 1

    for (k in seq_len(p)) { # For each parameter
      pname <- names(fixed_designs)[k]
      if (!is.null(random_designs[[pname]])) {
        # Prior precision in parameter space
        prec_noise <- tvinv[k, k]

        # Track component sizes and indices for this parameter
        z_list <- random_designs[[pname]]
        comp_sizes <- vapply(z_list, ncol, integer(1))
        comp_starts <- u_ptr + c(0, cumsum(comp_sizes))[seq_along(comp_sizes)]

        # Now iterate over components for THIS parameter k
        for (j in seq_along(z_list)) {
          z <- z_list[[j]]
          n_u <- comp_sizes[j]
          curr_idx <- comp_starts[j]:(comp_starts[j] + n_u - 1)
          curr_s2 <- s_new[s_ptr]

          # Recompute total random effect contribution with current u_new
          total_rand_offset <- numeric(n)
          for (jj in seq_along(z_list)) {
            idx_jj <- comp_starts[jj]:(comp_starts[jj] + comp_sizes[jj] - 1)
            total_rand_offset <- total_rand_offset + as.vector(z_list[[jj]] %*% u_new[idx_jj])
          }

          # Recompute cross-correlation adjustment with current u_new
          mu_full <- calculate_subject_means_RE(fixed_designs, tmu_new, random_designs, u_new, random_maps)
          devs <- alpha - mu_full

          weighted_devs <- (tvinv %*% devs)[k, ]
          other_terms <- weighted_devs - tvinv[k, k] * devs[k, ]
          adjustment <- -other_terms / tvinv[k, k]

          # Base target for this component is the residual after removing fixed effects,
          # total random effects, and the cross-correlation adjustment.
          base_target <- alpha[k, ] - mu_fixed[k, ] - total_rand_offset - adjustment

          current_u_segment <- u_new[curr_idx]

          # Isolate the current random effect component (u_curr) from the residuals.
          # base_target excludes all random effects, so we add back the current
          # component (Z * u_segment) to get the target for this update step.
          target <- base_target + as.vector(z %*% current_u_segment)

          # Bayesian Linear Regression Update for u
          # Prior u ~ N(0, s^2), Error Precision = prec_noise
          ztz <- crossprod(z)
          # If z is indicator, ztz is diagonal.

          post_prec <- prec_noise * ztz
          diag(post_prec) <- diag(post_prec) + 1 / curr_s2

          post_cov <- solve(post_prec)

          post_mean <- post_cov %*% (prec_noise * crossprod(z, target))

          # Sample new u
          L_u <- t(chol(post_cov))
          u_drawn <- as.vector(post_mean + L_u %*% rnorm(n_u))

          # Update u_new
          u_new[curr_idx] <- u_drawn

          # Update s for this component
          # s^2 | u ~ IG( v/2 + J/2, v/a_half_s + sum(u^2)/2 )
          # We sample the Variance (s^2) from the Inverse Gamma posterior.

          J_dim <- n_u
          shape_s <- (prior$v_Z + J_dim) / 2
          rate_s <- prior$v_Z / a_half_s_new[s_ptr] + 0.5 * sum(u_drawn^2)

          s2_new <- 1 / rgamma(1, shape = shape_s, rate = rate_s)

          # Store as Variance (s^2)
          s_new[s_ptr] <- s2_new

          # Update a_half_s (auxiliary variable for s variance)
          # Uses Inverse Gamma sampler (via 1/rgamma)
          # Selects A_z based on component index s_ptr
          val_A <- if (length(prior$A_z) >= s_ptr) prior$A_z[s_ptr] else prior$A_z[1]
          shape_a <- (prior$v_Z + 1) / 2

          a_half_s_new[s_ptr] <- 1 / rgamma(1, shape = shape_a, rate = prior$v_Z * (1 / s2_new) + 1 / (val_A^2))

          s_ptr <- s_ptr + 1
        }
        u_ptr <- u_ptr + sum(comp_sizes)
      }
    }

    # Final update of subj_mu with NEW u for residuals
    subj_mu <- calculate_subject_means_RE(fixed_designs, tmu_new, random_designs, u_new, random_maps)
  } else {
    subj_mu <- calculate_subject_means(fixed_designs, tmu_new)
  }

  ## --------------------------------------------------
  ## 3) Update Covariance (tvar)
  ## --------------------------------------------------

  resid <- alpha - subj_mu

  tvar_new <- matrix(0, p, p)
  blocked_idx <- which(is_blocked)
  unblocked_idx <- which(!is_blocked)

  if (length(blocked_idx) > 0) {
    block_groups <- unique(par_group[blocked_idx])
    for (g in block_groups) {
      group_idx <- blocked_idx[par_group[blocked_idx] == g]
      d <- length(group_idx)
      resid_block <- resid[group_idx, , drop = FALSE]
      cov_block <- resid_block %*% t(resid_block)

      B_half_block <- 2 * prior$v * diag(1 / a_half[group_idx], d) + cov_block
      df_block <- prior$v + d - 1 + n

      Sigma_block <- riwish(df_block, B_half_block)
      tvar_new[group_idx, group_idx] <- Sigma_block
    }
  }

  if (length(unblocked_idx) > 0) {
    sum_sq_vec <- rowSums(resid[unblocked_idx, , drop = FALSE]^2)
    shape_vec <- prior$v / 2 + n / 2
    rate_vec <- prior$v / a_half[unblocked_idx] + 0.5 * sum_sq_vec

    tvinv_diag <- rgamma(length(unblocked_idx), shape = shape_vec, rate = rate_vec)
    tvar_diag <- 1 / tvinv_diag

    tvar_new[cbind(unblocked_idx, unblocked_idx)] <- tvar_diag
  }

  tvinv_new <- solve(tvar_new)

  block_dim <- integer(p)
  block_dim[unblocked_idx] <- 1
  if (length(blocked_idx) > 0) {
    block_groups <- unique(par_group[blocked_idx])
    for (g in block_groups) {
      group_idx <- blocked_idx[par_group[blocked_idx] == g]
      block_dim[group_idx] <- length(group_idx)
    }
  }

  shape_vec <- (prior$v + block_dim) / 2
  rate_vec <- prior$v * diag(tvinv_new) + 1 / (prior$A^2)
  a_half_new <- 1 / rgamma(p, shape = shape_vec, rate = rate_vec)

  out <- list(
    tmu = tmu_new,
    tvar = tvar_new,
    tvinv = tvinv_new,
    a_half = a_half_new,
    subj_mu = subj_mu,
    alpha = alpha
  )
  if (has_random) {
    out$u <- u_new
    out$s <- s_new
    out$a_half_s <- a_half_s_new
  }
  return(out)
}


# Interweaving (ASIS) scale move -----------------------------------------------
#
# The centred alternation "subjects | (mu, Sigma)" / "(mu, Sigma) | subjects"
# mixes slowly where a group variance is small relative to what the subjects'
# data say about them (the hierarchical funnel): with Sigma_jj tiny the
# subjects cannot move away from mu_j, and with the subjects at mu_j the
# conjugate draw of Sigma_jj stays tiny (rating-work/sampler/hier/stageH1/
# REPORT.md: autocorrelation time of log SD about 500 iterations even with an
# exact subject draw). This move is the non-centred step of Yu & Meng's (2011)
# ancillarity-sufficiency interweaving: for each parameter j it rescales the
# group SD, every subject's deviation from mu_j and the prior's auxiliary
# variable a_j together,
#   alpha'_sj = mu_sj + f (alpha_sj - mu_sj),  Sigma' = D Sigma D,  a'_j = a_j / f^2,
#   D = diag(1, .., f, .., 1),  f = exp(delta),  delta ~ N(0, step_j^2).
# In the non-centred parameterisation the standardised deviations do not
# change, so the group density's quadratic form is unchanged, and with a_j
# scaled along the prior's trace term v [Sigma^-1]_jj / a_j is unchanged
# too. What is left of the prior ratio and the Jacobian is the same for
# every covariance block size d (group density f^-n; Jacobians f^n of the
# deviations, f^(d + 1) of the block, f^-2 of a_j; the inverse-Wishart
# IW(v + d - 1, 2 v diag(1 / a)) determinant f^-(v + 2 d) and normalising
# constant f^(v + d - 1); the IG(1/2, 1/A_j^2) prior of a_j):
#   log r = sum_s [l_s(alpha'_s) - l_s(alpha_s)] + delta - (exp(2 delta) - 1) / (A_j^2 a_j)
# (scale_move_log_prior(), checked against a brute-force evaluation in
# test-scale-move.R). Scaling a_j along matters: with a_j held, the ratio is
# -(v + d - 1) delta - (v / a_j) [Sigma^-1]_jj (exp(-2 delta) - 1), a
# Gamma((v + d) / 2, .) conditional for the scaled precision, so on a
# 25-parameter block each accepted move changes log SD by about 0.15 and the
# chain crawls along the a_j - Sigma_jj ridge instead (IAT of log group SD
# still about 100 on the p25 conjugate cell); with a_j scaled along the
# conditional is as wide as the half-t marginal.
#
# The same alternation pins the group means when a group SD is small: mu_j |
# alpha has SD tau_j / sqrt(n) and the subjects cannot leave mu_j, so with
# the scale move alone the group means of the weak parameters still had an
# autocorrelation time of 40-130 iterations on the p25 cell. The sweep
# therefore also has a location move per parameter, the non-centred step
# for the mean: mu'_j = mu_j + e, alpha'_sj = alpha_sj + e, e ~ N(0, loc_j^2),
# which leaves the deviations and so the group density unchanged and is
# accepted with the likelihood ratios and the ratio of the N(m0, V0) prior
# of mu (a translation: no Jacobian). It runs when the group level has no
# design (mu_j is then the subjects' common mean); with a group design the
# move would have to act on the intercept, which is left open.
#
# A sweep over all parameters would cost p likelihood evaluations per subject
# per iteration. Instead the sweep runs on the quadratic approximation of each
# subject's log-likelihood that the particle step already has (lik_prec,
# H1b), in a random order, which gives a Markov kernel that is reversible for
# the approximate posterior; the result is then proposed to the exact
# posterior and accepted with the ratio of the exact to the approximate
# likelihood ratios, which costs ONE likelihood evaluation per subject
# (delayed acceptance / surrogate transition, Christen & Fox 2005; Liu 2001,
# section 9.4). The stationary distribution is the exact posterior whatever
# the quality of the approximation; a poor one just lowers the acceptance.
# Where the approximation is exact (a Gaussian likelihood) every sweep is
# accepted. Subjects without a likelihood precision get a flat surrogate.
# Because the approximation's error adds up over the moves a sweep accepts
# (one sweep of 25 LNR parameters x 20 subjects was accepted 6% of the
# time), the sweep is dealt into blocks of parameters, each accepted or
# rejected on its own; the number of blocks adapts to the block acceptance.
#
# The step sizes are adapted (Robbins-Monro, target scale_move_target) in
# adapt and in the tail of adapt that tunes the sample kernel, where their
# log average is also recorded; tune_sample_kernel() freezes them at that
# average and nothing adapts in the sample stage (H1b's rule: no adaptation
# once draws are kept). The acceptance they adapt on is the REALISED one: a
# move counts as accepted when the surrogate accepted it AND its block then
# passed the exact check. Adapting on the surrogate's acceptance alone
# tunes the step to the surrogate, whatever its quality: where the
# surrogate is wrong about a parameter its acceptance says nothing about
# the exact move, so the step can settle anywhere -- it ran away to 6-11
# log-SD units on forstmann's DDM sv and SZ (rating-work/sampler/hier/
# stageH3/REPORT.md section 2a, stageH5/REPORT.md), where the surrogate's
# gradient and curvature were wrong by three orders of magnitude (the
# finite-difference step of lik_precision() straddled the likelihood's
# floor at the model's bound), the inner acceptance was a coin toss on the
# sign of the proposal at any step, and the exact check rejected nearly
# every such block, leaving the group SD to the slow centred random walk.
# With the realised acceptance the exact check's rejections shrink the
# step until the rescaling is one the exact likelihoods accept, which is
# the step a random walk on the exact conditional wants, and a surrogate
# that is flat in a parameter (no curvature, no gradient: the inner ratio
# is the prior part alone) gets the step the prior and the exact check
# agree on. Where the surrogate is exact (a Gaussian likelihood) every
# block passes and nothing changes. The same holds for the location step.
# The target of the realised acceptance is scale_move_target x r, with r a
# running average of the block acceptance (r_block: exponentially weighted,
# weight scale_move_r_weight per sweep, starting at 1, updated after the
# steps so that a sweep's target does not depend on its own outcome, and
# frozen with the steps). A parameter whose moves are innocuous has a
# realised acceptance of about its surrogate acceptance x r -- its moves
# share the fate of the block -- so a target of scale_move_target alone
# pushed the surrogate acceptance of every parameter to scale_move_target /
# r and the steps to a quarter of what the surrogate allows through blocks
# that pass about half the time, which cost group-SD mixing on the hardest
# grid cell (stageH5/REPORT.md section 4, stageH5b/REPORT.md). With the
# target scaled by r such a parameter's surrogate acceptance returns to
# scale_move_target, a parameter whose moves make blocks fail more often
# than the average block still shrinks, and with r = 1 (surrogate exact)
# nothing changes. r enters the target no lower than scale_move_r_floor,
# the block acceptance below which the sweep is split into more blocks: a
# lower r means the blocks cannot be split further and still fail, i.e. the
# surrogate is poor for most parameters, and without the floor larger steps
# would lower r and with it the target (on the flat-surrogate toy of
# test-scale-move.R the steps then go to 10-20 at a realised acceptance of
# .06).
# State lives in attr(samples, "scale_move") and travels with the chain
# (concat_emc); acc_in / acc_loc count the surrogate's acceptances and
# acc_real / acc_loc_real the realised ones.
#
# Many subjects (Stage H6b). The surrogate's error has the same sign in
# nearly every subject (the likelihood's skew), so in a move common to all
# subjects it adds up with n while the move's tolerance grows with sqrt(n):
# with several hundred subjects the moves of well-identified parameters pass
# the exact check only at steps far below the posterior SD of what they
# move, while each block still costs one likelihood evaluation per subject
# (Eisenberg Simon, 518 subjects: 2.8 times the run time for no gain in
# mixing; rating-work/sampler/hier/stageH6/REPORT.md). Two things follow.
# The steps start at the moves' conditional scale on the surrogate where
# that is below the default start (they come down slowly: at most
# gain x target per sweep). And the sweep is gated (scale_move_gate): a
# move that adds little to what the group-level Gibbs step does anyway is
# left out for the rest of the fit, decided after each step of adapt once
# the steps have had adapt_converge$min sweeps to settle (run_emc) -- and only
# when the sweep is already split into as many blocks as it has parameters,
# so a sweep whose blocks pass is never touched.
#
# options(emc.scale_move = FALSE) turns the move off (A/B); a character
# vector names the stages it runs in (default adapt and sample); the legacy
# sampler never runs it.

scale_move_target <- .3
scale_move_r_weight <- .05
scale_move_r_floor <- .35
scale_move_kappa <- .1

scale_move_stages <- function(){
  if(legacy_sampler()) return(character(0))
  opt <- getOption("emc.scale_move")
  if(is.null(opt) || isTRUE(opt)) return(c("adapt", "sample"))
  if(isFALSE(opt)) return(character(0))
  as.character(opt)
}

# Prior + group-density + Jacobian part of the log acceptance ratio of a
# log-scale change delta of parameter j with a_j scaled along (everything
# but the likelihoods)
scale_move_log_prior <- function(delta, A_j, a_j){
  delta - (exp(2 * delta) - 1) / (A_j^2 * a_j)
}

# step: the scale move's step sizes (log SD scale); loc: the location move's
# (parameter scale); the *_sum / *_n fields average their logs over the tail
# of adapt; blocks: the number of blocks the sweep is split into (win_*: the
# block acceptance window that adapts it); acc_in / acc_loc / n_in count the
# sweep's inner (surrogate) acceptances, acc_real / acc_loc_real the
# realised ones (inner AND the block's exact check, what the step sizes
# adapt on) and acc_out / n_out the delayed-acceptance step's (per block);
# r_block: the running block acceptance that scales the steps' target.
scale_move_init <- function(settings, par_names){
  p <- length(par_names)
  zero <- setNames(rep(0, p), par_names)
  if(is.null(settings)){
    settings <- list(step = zero + .5, log_step_sum = zero, log_step_n = zero,
                     loc = zero + .2, log_loc_sum = zero, log_loc_n = zero, uses = 0,
                     blocks = 1, win_acc = 0, win_n = 0,
                     acc_in = zero, acc_loc = zero, n_in = zero, acc_out = 0, n_out = 0, iter = 0,
                     acc_real = zero, acc_loc_real = zero, r_block = 1)
  }
  # state saved before the realised counters existed
  if(is.null(settings$acc_real)) settings$acc_real <- zero
  if(is.null(settings$acc_loc_real)) settings$acc_loc_real <- zero
  # ... and before the running block acceptance did
  if(is.null(settings$r_block)) settings$r_block <- 1
  # ... and before the gate did: every move is in the sweep
  if(is.null(settings$active_scale)) settings$active_scale <- zero == 0
  if(is.null(settings$active_loc)) settings$active_loc <- zero == 0
  settings
}

# The gate, for all chains' settings `sm` at once. A move (the scale move or
# the location move of one parameter) is dropped from the sweep, for the rest
# of the fit, when
# (i) the sweep cannot be split into more blocks: every chain already has as
#     many blocks as there are parameters still in the sweep; and
# (ii) the move adds little to what the group-level Gibbs step does anyway:
#     its expected squared jump per sweep since the last call (realised
#     acceptance x step^2) is below scale_move_kappa times the Gibbs step's
#     own, the conditional variance of the quantity given the subjects (about
#     1 / (2 n) for a log group SD and group variance / n for a group mean,
#     n subjects).
# Both are taken as shares of the posterior variance of the quantity moved
# (var_lsd: log group SD, var_mu: group mean, NULL without location moves;
# mean_var: mean group variance; all per parameter, from one stretch of
# draws pooled over chains), so that in a funnel, where the Gibbs step's
# share is small, a move with a small step is still kept. The chains decide
# jointly (mean of their values). Realised acceptance alone would not do:
# given enough adapt iterations the steps reach their acceptance target at
# a useless size. decide = FALSE only records the values and restarts the
# counters. What was decided is kept in settings$gate (one entry per call)
# and settings$active_scale / active_loc.
scale_move_gate <- function(sm, var_lsd, var_mu, mean_var, n_subjects, decide = TRUE){
  p <- length(sm[[1]]$step)
  act_s <- sm[[1]]$active_scale; act_l <- sm[[1]]$active_loc
  if(is.null(act_s)) act_s <- rep(TRUE, p)
  if(is.null(act_l)) act_l <- rep(TRUE, p)
  if(is.null(var_mu)) act_l <- rep(FALSE, p)
  n_act <- sum(act_s | act_l)
  u <- lapply(sm, function(x){
    m <- x$mark
    if(is.null(m)) m <- list(acc_real = 0 * x$acc_real, acc_loc_real = 0 * x$acc_loc_real, n_in = 0 * x$n_in)
    n <- pmax(1, x$n_in - m$n_in)
    list(us = (x$acc_real - m$acc_real) / n * x$step^2 / var_lsd,
         ul = if(is.null(var_mu)) rep(0, p) else (x$acc_loc_real - m$acc_loc_real) / n * x$loc^2 / var_mu)
  })
  us <- Reduce(`+`, lapply(u, `[[`, "us")) / length(u)
  ul <- Reduce(`+`, lapply(u, `[[`, "ul")) / length(u)
  us[!is.finite(us)] <- Inf; ul[!is.finite(ul)] <- Inf     # no posterior variance yet: keep
  gs <- pmin(1, 1 / (2 * n_subjects) / var_lsd)
  gl <- if(is.null(var_mu)) rep(1, p) else pmin(1, mean_var / n_subjects / var_mu)
  gs[!is.finite(gs)] <- 0; gl[!is.finite(gl)] <- 0
  full <- n_act > 0 && all(sapply(sm, function(x) x$blocks >= n_act))
  if(decide && full){
    act_s <- act_s & !(us < scale_move_kappa * gs)
    act_l <- act_l & !(ul < scale_move_kappa * gl)
  }
  lapply(sm, function(x){
    x$active_scale <- setNames(act_s, names(x$step)); x$active_loc <- setNames(act_l, names(x$step))
    x$gate <- c(x$gate, list(list(sweeps = x$n_in[1], decide = decide, full = full, blocks = x$blocks, r_block = x$r_block,
                                  u_scale = us, u_loc = ul, gibbs_scale = gs, gibbs_loc = gl,
                                  active_scale = act_s, active_loc = act_l)))
    x$mark <- list(acc_real = x$acc_real, acc_loc_real = x$acc_loc_real, n_in = x$n_in)
    x
  })
}

# Start averaging the step sizes (the tail of adapt) ...
scale_move_reset_tail <- function(settings){
  settings$uses <- 0
  settings$log_step_sum[] <- 0; settings$log_step_n[] <- 0
  settings$log_loc_sum[] <- 0; settings$log_loc_n[] <- 0
  settings
}

# ... and freeze them at the average for the sample stage
scale_move_freeze <- function(settings){
  ok <- settings$log_step_n >= 10
  settings$step[ok] <- exp(settings$log_step_sum[ok] / settings$log_step_n[ok])
  ok <- settings$log_loc_n >= 10
  settings$loc[ok] <- exp(settings$log_loc_sum[ok] / settings$log_loc_n[ok])
  settings
}

# One sweep of the move. pars: the group step's output (tmu, tvar, tvinv,
# a_half, subj_mu, alpha = the p x n non-nuisance alphas); alpha_full: all
# n_pars x n current alphas; prev_ll: the subjects' current log-likelihoods.
# Returns the (possibly) updated pars, alpha_full, ll and settings.
scale_move_standard <- function(sampler, pars, alpha_full, prev_ll, settings, lik_prec,
                                frozen = FALSE, n_cores = 1, r_cores = 1, gain = .1){
  # the gate left no move in the sweep
  if(!is.null(settings$active_scale) && !any(settings$active_scale | settings$active_loc))
    return(list(pars = pars, alpha = alpha_full, ll = prev_ll, settings = settings))
  nuisance <- sampler$nuisance
  if(is.null(nuisance)) nuisance <- rep(FALSE, nrow(alpha_full))
  keep <- which(!nuisance)
  p <- length(keep); n <- ncol(alpha_full)
  A <- rep(sampler$prior$A, length.out = p)
  a <- pars$a_half
  tvar <- pars$tvar; tvinv <- pars$tvinv
  R <- pars$alpha - pars$subj_mu          # deviations, p x n
  # location moves: only without a group design (then tmu is the p-vector of
  # common means and the prior on it N(m0, V0))
  do_loc <- is.null(sampler$group_designs) && length(pars$tmu) == p
  if(do_loc){
    tmu <- pars$tmu
    P0 <- sampler$prior$theta_mu_invar
    pr <- drop(P0 %*% (tmu - sampler$prior$theta_mu_mean))
    mu_shift <- rep(0, p)
  }
  # surrogate: gradient g_s = lin_s - L_s alpha_s and curvature L_s,jj per subject
  G <- matrix(0, nrow(alpha_full), n)
  Ljj <- matrix(0, nrow(alpha_full), n)
  has_lik <- rep(FALSE, n)
  for(s in seq_len(n)){
    lik <- lik_prec[[s]]
    if(is.null(lik) || is.null(lik$prec)) next
    has_lik[s] <- TRUE
    G[, s] <- lik$lin - drop(lik$prec %*% alpha_full[, s])
    Ljj[, s] <- diag(lik$prec)
  }
  pn <- rownames(alpha_full)
  alpha_new <- alpha_full
  # acc_sur / acc_sur_loc: accepted on the surrogate; acc / acc_loc: and the
  # block then passed the exact check (the realised acceptance the step
  # sizes adapt on)
  acc <- acc_loc <- acc_sur <- acc_sur_loc <- rep(0, p)
  blk_n <- blk_acc <- 0                   # this sweep's blocks checked / passed
  # The sweep, in B blocks: the parameters are dealt into B random blocks, each
  # block's scale and location moves run in random order on the surrogate,
  # and each block is then accepted or rejected against the exact likelihoods
  # (one evaluation per subject per block). The surrogate's error grows with
  # the number of moves a block accepts, so B is adapted in adapt to keep the
  # block acceptance in [.35, .75] (one block where the surrogate is exact)
  # and is frozen for sample.
  # The moves the gate kept (scale_move_gate); a parameter with neither move
  # is in no block.
  act_s <- if(is.null(settings$active_scale)) rep(TRUE, p) else settings$active_scale
  act_l <- if(!do_loc) rep(FALSE, p) else if(is.null(settings$active_loc)) rep(TRUE, p) else settings$active_loc
  act <- which(act_s | act_l)
  B <- max(1, min(length(act), settings$blocks))
  blocks <- if(length(act) == 0) list() else
    split(act[sample.int(length(act))], rep(seq_len(B), length.out = length(act)))
  # First sweep: start the steps at the moves' conditional scale on the
  # surrogate where that is below the default start
  if(!frozen && settings$iter == 0){
    cs <- 2.4 / sqrt(rowSums(R^2 * Ljj[keep, , drop = FALSE]) + 4 / (A^2 * a))
    ok <- is.finite(cs) & cs > 0
    settings$step[ok] <- pmax(1e-4, pmin(settings$step, cs))[ok]
    if(do_loc){
      cl <- 2.4 / sqrt(rowSums(Ljj[keep, , drop = FALSE]) + diag(P0))
      ok <- is.finite(cl) & cl > 0
      settings$loc[ok] <- pmax(1e-4, pmin(settings$loc, cl))[ok]
    }
  }
  for(blk in blocks){
    # the block's start state, restored if the block is rejected
    R0 <- R; a0 <- a; G0 <- G; alpha0 <- alpha_new
    if(do_loc){ tmu0 <- tmu; pr0 <- pr; mu_shift <- rep(0, p) }
    f_acc <- rep(1, p)
    surr <- numeric(n)                    # accumulated surrogate log-likelihood change
    moved <- FALSE
    moves <- c(blk[act_s[blk]], (blk + p)[act_l[blk]])
    moves <- moves[sample.int(length(moves))]
    for(k in moves){
      scale <- k <= p
      j <- if(scale) k else k - p
      jj <- keep[j]
      if(scale){
        delta <- rnorm(1, 0, settings$step[j]); f <- exp(delta)
        d <- (f - 1) * R[j, ]
        lp <- scale_move_log_prior(delta, A[j], a[j])
      } else{
        e <- rnorm(1, 0, settings$loc[j])
        d <- rep(e, n)
        lp <- -e * pr[j] - .5 * e^2 * P0[j, j]
      }
      dsurr <- d * G[jj, ] - .5 * d^2 * Ljj[jj, ]
      lr <- sum(dsurr) + lp
      if(is.finite(lr) && log(runif(1)) < lr){
        moved <- TRUE
        alpha_new[jj, ] <- alpha_new[jj, ] + d
        for(s in which(has_lik)) G[, s] <- G[, s] - d[s] * lik_prec[[s]]$prec[, jj]
        surr <- surr + dsurr
        if(scale){
          acc_sur[j] <- 1
          R[j, ] <- f * R[j, ]
          a[j] <- a[j] / f^2
          f_acc[j] <- f_acc[j] * f
        } else{
          acc_sur_loc[j] <- 1
          tmu[j] <- tmu[j] + e
          pr <- pr + e * P0[, j]
          mu_shift[j] <- mu_shift[j] + e
        }
      }
    }
    if(!moved) next
    settings$n_out <- settings$n_out + 1
    # The block's exact check: one likelihood per subject. Forking n_cores
    # children for it costs more than the likelihoods themselves when they
    # are cheap (518 subjects x ~100 trials: about 30 ms in this process
    # against 230 ms forked from a fit's process, eight times per iteration),
    # so the first checks are timed both ways, three each, and the faster way
    # is kept (settings$check_serial). The values do not depend on the way.
    ll_one <- function(s){
      x <- matrix(alpha_new[, s], nrow = 1, dimnames = list(NULL, pn))
      as.numeric(calc_ll_manager(x, dadm = sampler$data[[s]], model = sampler$model, r_cores = r_cores))
    }
    serial <- if(n_cores <= 1) TRUE else settings$check_serial
    timing <- is.null(serial)
    if(timing) serial <- length(settings$check_time$serial) <= length(settings$check_time$parallel)
    t_check <- proc.time()[["elapsed"]]
    ll_new <- if(serial) unlist(lapply(seq_len(n), ll_one)) else
      unlist(parallel::mclapply(seq_len(n), ll_one, mc.cores = n_cores))
    if(timing){
      t_check <- proc.time()[["elapsed"]] - t_check
      if(serial) settings$check_time$serial <- c(settings$check_time$serial, t_check)
      else settings$check_time$parallel <- c(settings$check_time$parallel, t_check)
      if(length(settings$check_time$parallel) >= 3)
        settings$check_serial <- min(settings$check_time$serial) <= min(settings$check_time$parallel)
    }
    lr_out <- sum(ll_new - prev_ll) - sum(surr)
    if(is.finite(lr_out) && log(runif(1)) < lr_out){
      settings$acc_out <- settings$acc_out + 1
      settings$win_acc <- settings$win_acc + 1
      blk_acc <- blk_acc + 1
      tvar <- tvar * outer(f_acc, f_acc)
      tvinv <- tvinv / outer(f_acc, f_acc)
      if(do_loc) pars$subj_mu <- pars$subj_mu + mu_shift
      alpha_full <- alpha_new
      prev_ll <- ll_new
      acc[blk] <- acc_sur[blk]; acc_loc[blk] <- acc_sur_loc[blk]
    } else{
      R <- R0; a <- a0; G <- G0; alpha_new <- alpha0
      if(do_loc){ tmu <- tmu0; pr <- pr0 }
    }
    settings$win_n <- settings$win_n + 1
    blk_n <- blk_n + 1
  }
  pars$tvar <- tvar; pars$tvinv <- tvinv
  pars$a_half <- a
  if(do_loc) pars$tmu <- tmu
  pars$alpha <- alpha_full[keep, , drop = FALSE]
  settings$acc_in <- settings$acc_in + acc_sur
  settings$acc_loc <- settings$acc_loc + acc_sur_loc
  settings$acc_real <- settings$acc_real + acc
  settings$acc_loc_real <- settings$acc_loc_real + acc_loc
  settings$n_in <- settings$n_in + 1
  settings$iter <- settings$iter + 1
  if(!frozen){
    target <- scale_move_target * max(settings$r_block, scale_move_r_floor)
    settings$step[act_s] <- exp(log(settings$step[act_s]) + gain * (acc[act_s] - target))
    if(do_loc) settings$loc[act_l] <- exp(log(settings$loc[act_l]) + gain * (acc_loc[act_l] - target))
    # the running block acceptance, for the next sweep's target (in this form
    # it stays exactly 1 while every block passes)
    if(blk_n > 0) settings$r_block <- settings$r_block +
        scale_move_r_weight * (blk_acc / blk_n - settings$r_block)
    settings$uses <- settings$uses + 1
    if(settings$uses > 20){
      settings$log_step_sum <- settings$log_step_sum + log(settings$step)
      settings$log_step_n <- settings$log_step_n + 1
      if(do_loc){
        settings$log_loc_sum <- settings$log_loc_sum + log(settings$loc)
        settings$log_loc_n <- settings$log_loc_n + 1
      }
    }
    # number of blocks, from the block acceptance over a window of 40 blocks
    if(settings$win_n >= 40){
      rate <- settings$win_acc / settings$win_n
      if(rate < scale_move_r_floor) settings$blocks <- min(max(1, length(act)), 2 * settings$blocks)
      else if(rate > .75) settings$blocks <- max(1, settings$blocks %/% 2)
      settings$win_acc <- settings$win_n <- 0
    }
  }
  list(pars = pars, alpha = alpha_full, ll = prev_ll, settings = settings)
}

last_sample_standard <- function(store) {
  tmu <- store$theta_mu[, store$idx, drop = TRUE]
  names(tmu) <- rownames(store$theta_mu)
  p_names <- dimnames(store$theta_var)[[1]]
  p <- dim(store$theta_var)[1]
  out <- list(
    tmu = tmu,  # Now includes beta
    tvar = .standard_square_matrix(store$theta_var[, , store$idx], p, p_names),
    tvinv = .standard_square_matrix(store$last_theta_var_inv, p, p_names),
    a_half = store$a_half[, store$idx]
  )
  if (!is.null(store$theta_u)) out$u <- store$theta_u[, store$idx]
  if (!is.null(store$theta_s)) {
    out$s <- store$theta_s[, store$idx]
    out$a_half_s <- store$a_half_s[, store$idx]
  }
  return(out)
}

get_conditionals_standard <- function(s, samples, n_pars, iteration = NULL, idx = NULL) {
  iteration <- ifelse(is.null(iteration), samples$iteration, iteration)
  if(is.null(idx)) idx <- 1:n_pars
  if(is.logical(idx)) idx <- which(idx)
  n_idx <- length(idx)
  alpha_samples <- matrix(samples$alpha[idx, s, , drop = FALSE], nrow = n_idx)
  theta_mu_samples <- if (!is.null(samples$subj_mu)) {
    matrix(samples$subj_mu[idx, s, , drop = FALSE], nrow = n_idx)
  } else {
    matrix(samples$theta_mu[idx, , drop = FALSE], nrow = n_idx)
  }
  pts2_unwound <- .standard_theta_var_draws(samples$theta_var, idx)
  all_samples <- rbind(alpha_samples, theta_mu_samples, pts2_unwound)
  mu_tilde <- rowMeans(all_samples)
  var_tilde <- if (length(mu_tilde) == 1L) {
    matrix(stats::var(as.numeric(all_samples)), nrow = 1L, ncol = 1L)
  } else {
    stats::cov(t(all_samples))
  }
  theta_var_iteration <- .standard_square_matrix(
    samples$theta_var[idx, idx, iteration, drop = FALSE],
    n_idx,
    rownames(theta_mu_samples)
  )
  condmvn <- condMVN(mean = mu_tilde, sigma = var_tilde,
                     dependent.ind = 1:n_idx, given.ind = (n_idx + 1):length(mu_tilde),
                     X.given = c(theta_mu_samples[, iteration], unwind(theta_var_iteration)))
  return(list(eff_mu = condmvn$condMean, eff_var = condmvn$condVar))
}

unwind <- function(var_matrix, ...) {
  y <- t(chol(var_matrix))
  diag(y) <- log(diag(y))
  y[lower.tri(y, diag = TRUE)]
}

filtered_samples_standard <- function(sampler, filter, ...) {
  out <- list(
    theta_mu = sampler$samples$theta_mu[, filter, drop = F],
    theta_var = sampler$samples$theta_var[, , filter, drop = F],
    alpha = sampler$samples$alpha[, , filter, drop = F],
    iteration = length(filter)
  )
  if (!is.null(sampler$group_designs)) {
    par_names <- dimnames(out$alpha)[[1]]
    n_subjects <- dim(out$alpha)[2]
    fixed_designs <- add_group_design(par_names, sampler$group_designs, n_subjects)
    random_designs <- add_group_design_random(par_names, sampler$group_designs)
    random_maps <- add_group_design_map(par_names, sampler$group_designs)
    theta_u <- if (!is.null(sampler$samples$theta_u)) {
      sampler$samples$theta_u[, filter, drop = FALSE]
    } else {
      NULL
    }
    out$subj_mu <- array(NA_real_,
                         dim = dim(out$alpha),
                         dimnames = dimnames(out$alpha))
    for (i in seq_len(out$iteration)) {
      u <- if (!is.null(theta_u)) theta_u[, i, drop = TRUE] else NULL
      out$subj_mu[, , i] <- calculate_subject_means_RE(
        fixed_designs, out$theta_mu[, i, drop = TRUE],
        random_designs, u, random_maps
      )
    }
  }
  out
}


calc_log_jac_chol <- function(x) {
  ## work out dimension -------------------------------------------------
  n <- floor(sqrt(2 * length(x) + 0.25) - 0.5) # solves n(n+1)/2 = length(x)

  ## rebuild the raw lower‑triangular matrix ----------------------------
  mat <- matrix(NA_real_, n, n)
  mat[lower.tri(mat, diag = TRUE)] <- x # raw params (diag on log‑scale)

  ## step 1: create L ---------------------------------------------------
  L <- mat
  diag(L) <- exp(diag(mat)) # positive diagonal
  # (off‑diagonals stay on natural scale)

  ## log‑Jacobian -------------------------------------------------------
  logL <- diag(mat) # log of L_ii
  log_jac <- n * log(2) + sum((n - seq_len(n) + 2) * logL)

  return(log_jac)
}

unwind_chol <- function(x, reverse = FALSE) {
  if (reverse) {
    n <- sqrt(2 * length(x) + 0.25) - 0.5 ## Dim of matrix.
    out <- array(0, dim = c(n, n))
    out[lower.tri(out, diag = TRUE)] <- x
    diag(out) <- exp(diag(out))
    out <- out %*% t(out)
  } else {
    y <- t(base::chol(x))
    diag(y) <- log(diag(y))
    out <- y[lower.tri(y, diag = TRUE)]
  }
  return(out)
}

# bridge_sampling ---------------------------------------------------------
bridge_group_and_prior_and_jac_standard <- function(
    proposals_group, # (n_iter x [theta_mu, theta_a, var1, var2, u, s, a_s])
    proposals_list, # list of length n_subj, each item is (n_iter x p) alphas
    info) {
  # 'info' should contain:
  #   info$n_pars        = p        (# of rows in alpha)
  #   info$n_subjects    = n_subj   (# of subjects)
  #   info$is_blocked    = logical p  (which rows are blocked)
  #   info$par_group     = integer p  (group IDs for blocked rows)
  #   info$group_designs = list of length p, each (n_subj x m_k) [Full structure]
  #   info$prior:
  #       - $theta_mu_mean (p+B), $theta_mu_var ((p+B)x(p+B))
  #       - $v, $A (IW & gamma hyperparams)

  par_group <- info$par_group
  has_cov <- info$is_blocked
  block_groups <- unique(par_group[has_cov])
  prior <- info$prior

  p <- info$n_pars # dimension of each alpha_i
  n_subj <- info$n_subjects

  # Prepare designs
  # Fixed designs for mean calculation
  group_designs_fixed <- add_group_design(info$par_names, info$group_designs, n_subj)
  # Random designs for offset calculation
  random_designs <- add_group_design_random(info$par_names, info$group_designs)

  n_random <- get_n_random(info$par_names, info$group_designs)
  n_random_var <- get_n_random_variance(info$par_names, info$group_designs)

  # Total fixed parameters (including regressors)
  total_pars <- length(prior$theta_mu_mean)

  # Extract columns from proposals_group:
  # 1. theta_mu
  theta_mu <- proposals_group[, seq_len(total_pars), drop = FALSE]

  # 2. theta_a (log a_half)
  theta_a <- proposals_group[, total_pars + seq_len(p), drop = FALSE]
  min_idx <- total_pars + p

  # 3. theta_var1 (unblocked diagonals)
  if (any(!has_cov)) {
    theta_var1 <- proposals_group[, (min_idx + 1):(min_idx + sum(!has_cov)), drop = FALSE]
    min_idx <- min_idx + sum(!has_cov)
  }

  # 4. theta_var2 (blocked cholesky)
  if (any(has_cov)) {
    theta_var2_list <- list()
    for (block in block_groups) {
      cur_idx <- has_cov[par_group == block]
      n_cur <- sum(cur_idx)
      len_block <- (n_cur * (n_cur + 1)) / 2
      theta_var2_list[[block]] <- proposals_group[, (min_idx + 1):(min_idx + len_block), drop = FALSE]
      min_idx <- min_idx + len_block
    }
  }

  # 5. Random Effects (u, s, a_s)
  theta_u <- NULL
  theta_s <- NULL
  theta_a_s <- NULL

  if (n_random > 0) {
    # u (normal)
    theta_u <- proposals_group[, (min_idx + 1):(min_idx + n_random), drop = FALSE]
    min_idx <- min_idx + n_random

    # s (log SD)
    theta_s <- proposals_group[, (min_idx + 1):(min_idx + n_random_var), drop = FALSE]
    min_idx <- min_idx + n_random_var

    # a_half_s (log aux)
    theta_a_s <- proposals_group[, (min_idx + 1):(min_idx + n_random_var), drop = FALSE]
    min_idx <- min_idx + n_random_var
  }

  n_iter <- nrow(theta_mu)
  sum_out <- numeric(n_iter)

  # Precompute the vectorized prior on theta_mu
  prior_mu_log <- dmvnorm(theta_mu,
    mean  = prior$theta_mu_mean,
    sigma = prior$theta_mu_var,
    log   = TRUE
  )

  # Jacobians for var1, a
  if (any(!has_cov)) {
    jac_var1 <- rowSums(theta_var1)
  } else {
    jac_var1 <- 0
  }
  jac_a_vec <- rowSums(theta_a)

  # Jacobians for s and a_s (log transform)
  jac_s <- 0
  jac_a_s <- 0
  if (n_random > 0) {
    jac_s <- rowSums(theta_s)
    jac_a_s <- rowSums(theta_a_s)
  }

  #--- Main loop over MCMC draws ---
  for (i in seq_len(n_iter)) {
    # 1) Reconstruct partial-block var_curr
    var_curr <- matrix(0, p, p)

    # Unblocked diagonal => exp(theta_var1[i,])
    if (any(!has_cov)) {
      var_curr[!has_cov, !has_cov] <- diag(exp(theta_var1[i, ]), sum(!has_cov))
    }

    # Jacobian for var2
    jac_var2 <- 0
    prior_var2 <- 0
    # Blocked => unwind_chol
    if (any(has_cov)) {
      # Fill in theta_var2
      for (block in block_groups) {
        cur_idx <- par_group == block
        var_block <- unwind_chol(theta_var2_list[[block]][i, ], reverse = TRUE)
        var_curr[cur_idx, cur_idx] <- var_block
        # Prior influence
        d_block <- sum(cur_idx)
        prior_var2 <- prior_var2 + log(robust_diwish(
          W = var_block,
          v = prior$v + d_block - 1,
          S = 2 * prior$v * diag(1 / exp(theta_a[i, cur_idx]))
        ))
        # Jacobian influence
        jac_var2 <- jac_var2 + calc_log_jac_chol(theta_var2_list[[block]][i, ])
      }
    }

    # 2) Calculate Full Subject Means (incorporating u if present)
    u_vec <- NULL
    if (!is.null(theta_u)) u_vec <- theta_u[i, ]

    # Needs to be efficient: vectorized over subjects
    mu_full <- calculate_subject_means_RE(group_designs_fixed, theta_mu[i, ], random_designs, u_vec)

    # 3) Compute group likelihood = sum_{s=1..n_subj} dmvnorm(alpha_s, mu_s, var_curr)
    group_ll <- 0
    for (s in seq_len(n_subj)) {
      alpha_s <- proposals_list[[s]][i, ] # length p
      # mu_full is (p x n_subj)
      mu_s <- mu_full[, s]
      group_ll <- group_ll + dmvnorm(alpha_s, mu_s, var_curr, log = TRUE)
    }

    # 4) Prior on var1, var2, and a
    prior_var1 <- 0
    if (any(!has_cov)) {
      prior_var1 <- sum(logdinvGamma(
        x     = exp(theta_var1[i, ]),
        shape = prior$v / 2,
        rate  = prior$v / exp(theta_a[i, !has_cov, drop = FALSE])
      ))
    }

    prior_a <- sum(logdinvGamma(
      x     = exp(theta_a[i, ]),
      shape = 1 / 2,
      rate  = 1 / (prior$A^2)
    ))

    # 5) Prior on u, s, a_s
    prior_u <- 0
    prior_s <- 0
    prior_a_s <- 0

    if (n_random > 0) {
      # Current values
      s2_val <- exp(theta_s[i, ]) # vector of s^2 (Variance)
      a_s_val <- exp(theta_a_s[i, ]) # vector of a_half_s
      u_val <- theta_u[i, ]

      # prior_a_s: a_s ~ InverseGamma(1/2, 1/A_z^2)
      # calculated using logdinvGamma
      prior_a_s <- sum(logdinvGamma(
        x = a_s_val,
        shape = 1 / 2,
        rate = 1 / (prior$A_z^2)
      ))

      # prior_s: s^2 | a_s ~ InverseGamma(v_Z/2, v_Z/a_s)
      # s^2 is the parameter. We work with log(s^2).
      # The Jacobian for log(s^2) -> s^2 change of variable is handled by sum(theta_s).
      # So we calculate density of s^2 directly.
      prior_s <- sum(logdinvGamma(
        x = s2_val,
        shape = prior$v_Z / 2,
        rate = prior$v_Z / a_s_val
      ))

      # prior_u: u_k ~ N(0, s_k^2)
      # We need to map u indices to s indices.
      # Loop through parameters to handle mapping
      u_ptr <- 1
      s_ptr <- 1

      for (k in seq_along(info$par_names)) {
        pname <- info$par_names[k]
        if (!is.null(random_designs[[pname]])) {
          Z_parts <- random_designs[[pname]]
          for (j in seq_along(Z_parts)) {
            n_cols <- ncol(Z_parts[[j]])
            # Current s (SD) for this component
            curr_s <- sqrt(s2_val[s_ptr])

            # Current u chunk
            u_chunk <- u_val[u_ptr:(u_ptr + n_cols - 1)]

            # Density sum(dnorm(u, 0, s, log=T))
            prior_u <- prior_u + sum(dnorm(u_chunk, 0, curr_s, log = TRUE))

            u_ptr <- u_ptr + n_cols
            s_ptr <- s_ptr + 1
          }
        }
      }
    }

    # Combine
    sum_out[i] <- group_ll +
      prior_var1 + prior_var2 + jac_var2 + prior_a +
      prior_u + prior_s + prior_a_s
  } # end loop i

  # Add vectorized priors/Jacobians
  sum_out <- sum_out + prior_mu_log + jac_var1 + jac_a_vec + jac_s + jac_a_s

  return(sum_out)
}


bridge_add_info_standard <- function(info, samples) {
  if (is.null(samples$is_blocked)) {
    has_cov <- rep(T, samples$n_pars)
  } else {
    has_cov <- samples$is_blocked
  }
  info$par_group <- samples$par_group
  if (is.null(info$par_group)) {
    info$par_group <- rep(1, samples$n_pars)
  }
  info$is_blocked <- has_cov
  info$group_designs <- samples$group_designs
  info$par_names <- samples$par_names

  # Calculate total parameters (including former beta)
  n_total_pars <- nrow(samples$samples$theta_mu)

  # Base counts
  n_mu <- n_total_pars
  n_a <- samples$n_pars
  n_var <- sum(!has_cov)
  if (any(has_cov)) {
    block_groups <- unique(info$par_group[has_cov])
    for (g in block_groups) {
      d <- sum(has_cov & info$par_group == g)
      n_var <- n_var + (d * (d + 1)) / 2
    }
  }

  # Random effects counts
  n_u <- get_n_random(samples$par_names, samples$group_designs)
  n_s <- get_n_random_variance(samples$par_names, samples$group_designs)
  # a_half_s has same dim as s

  total_group_pars <- n_mu + n_a + n_var + n_u + n_s + n_s

  # Calculate group index including all parameters (theta_mu now includes beta, plus random effects)
  start_idx <- samples$n_pars * samples$n_subjects + 1
  info$group_idx <- start_idx:(start_idx + total_group_pars - 1)

  return(info)
}

bridge_add_group_standard <- function(all_samples, samples, idx) {
  # Add theta_mu (now includes all parameters)
  all_samples <- cbind(all_samples, t(samples$samples$theta_mu[, idx]))
  all_samples <- cbind(all_samples, t(log(samples$samples$a_half[, idx])))

  # Handle variance matrices
  par_group <- samples$par_group
  has_cov <- samples$is_blocked
  if (is.null(has_cov)) {
    has_cov <- rep(T, samples$n_pars)
  }
  if (is.null(par_group)) {
    par_group <- rep(1, samples$n_pars)
  }

  if (any(!has_cov)) {
    all_samples <- cbind(all_samples, t(log(matrix(apply(samples$samples$theta_var[!has_cov, !has_cov, idx, drop = F], 3, diag), ncol = nrow(all_samples)))))
  }
  if (any(has_cov)) {
    for (block in unique(par_group[has_cov])) {
      cur_idx <- par_group == block
      all_samples <- cbind(all_samples, t(matrix(apply(samples$samples$theta_var[cur_idx, cur_idx, idx, drop = F], 3, unwind_chol), ncol = nrow(all_samples))))
    }
  }

  # Add Random Effects u, s, a_half_s
  if (!is.null(samples$samples$theta_u)) {
    all_samples <- cbind(all_samples, t(samples$samples$theta_u[, idx, drop = FALSE]))
    # s (stored as SD)
    all_samples <- cbind(all_samples, t(log(samples$samples$theta_s[, idx, drop = FALSE])))
    # a_half_s
    all_samples <- cbind(all_samples, t(log(samples$samples$a_half_s[, idx, drop = FALSE])))
  }

  return(all_samples)
}

# for IC ------------------------------------------------------------------

group__IC_standard <- function(emc, stage = "sample", filter = NULL) {
  # 1) Retrieve draws
  alpha <- get_pars(emc, selection = "alpha", stage = stage, filter = filter,
                    return_mcmc = FALSE, merge_chains = TRUE)
  mu_selection <- if (is.null(emc[[1]]$group_designs)) "mu" else "beta"
  theta_mu <- get_pars(emc, selection = mu_selection, stage = stage, filter = filter,
                       return_mcmc = FALSE, merge_chains = TRUE)
  theta_var <- get_pars(emc, selection = "Sigma", stage = stage, filter = filter,
                        return_mcmc = FALSE, merge_chains = TRUE, remove_constants = F)

  p <- dim(alpha)[1] # number of subject-level parameters
  n_subj <- dim(alpha)[2] # number of subjects
  N <- dim(alpha)[3] # number of samples

  # 2) Averages
  mean_alpha <- apply(alpha, c(1, 2), mean)
  mean_mu <- rowMeans(theta_mu)
  mean_var <- apply(theta_var, c(1,2), mean)
  if (is.null(dim(mean_var))) {
    mean_var <- .standard_square_matrix(mean_var, 1L, rownames(theta_mu))
  }

  if (is.null(emc[[1]]$group_designs)) {
    lls <- numeric(N)
    for(i in 1:N){
      lls[i] <- sum(dmvnorm(t(alpha[,,i]), theta_mu[,i], .standard_square_matrix(theta_var[,,i], p, rownames(theta_mu)), log = T))
    }
    mean_pars_ll <- sum(dmvnorm(t(mean_alpha), mean_mu, mean_var, log = TRUE))
  } else {
    # 3) Build design matrices
    group_designs <- add_group_design(emc[[1]]$par_names, emc[[1]]$group_designs, n_subj)
    # 4) Per-draw log-likelihood
    lls <- standard_subj_ll(theta_var, theta_mu, alpha, n_subj, group_designs)
    # 5) Likelihood at posterior mean
    # Calculate subject-level means using the mean parameters
    mean_subj_means <- calculate_subject_means(group_designs, mean_mu)
    mean_pars_ll <- 0
    for (s in seq_len(n_subj)) {
      mean_pars_ll <- mean_pars_ll +
        dmvnorm(mean_alpha[, s], mean_subj_means[, s], mean_var, log = TRUE)
    }
  }

  minD <- -2 * max(lls)
  mean_ll <- mean(lls)
  Dmean <- -2 * mean_pars_ll
  list(mean_ll = mean_ll, Dmean = Dmean, minD = minD)
}

standard_subj_ll <- function(theta_var, theta_mu, alpha, n_subj, group_designs)
{
  N <- dim(theta_var)[3]
  p <- dim(alpha)[1]
  log2pi <- log(2*pi)

  # pre‑allocate
  ll <- numeric(N)

  for (i in seq_len(N)) {

    Sigma <- .standard_square_matrix(theta_var[,,i], p, dimnames(alpha)[[1]])
    U     <- chol(Sigma)              # will error if non‑PD
    rooti <- backsolve(U, diag(p))
    log_const <- sum(log(diag(rooti))) - 0.5 * p * log2pi

    mu <- calculate_subject_means(group_designs, theta_mu[, i])
    z <- t(alpha[, , i] - mu) %*% rooti # n_subj × p
    ll[i] <- -0.5 * sum(z^2) + n_subj * log_const
  }
  ll
}
